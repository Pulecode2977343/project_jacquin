﻿<?php
/**
 * connection.php - Conexion a la base de datos con PDO
 * Detecta automaticamente si estamos en local (XAMPP) o en produccion (InfinityFree)
 */

// --- DETECCION DE ENTORNO ---
$is_local = in_array($_SERVER['SERVER_NAME'] ?? 'localhost', ['localhost', '127.0.0.1'])
            || (php_uname('s') === 'Windows NT');

if ($is_local) {
    // --- DATOS DE TU PC (XAMPP) ---
    $host = 'localhost';
    $db_name = 'jam_db';
    $username = 'root';
    $password = ''; 
    $port = 3306;

    // Mostrar errores en desarrollo
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    // --- DATOS DE INFINITYFREE ---
    $host = 'sql311.infinityfree.com';
    $username = 'if0_40722917';
    $db_name = 'if0_40722917_jam_db';
    $password = 'TU_CONTRASENA_DEL_PANEL';
    $port = 3306;

    // Ocultar errores en produccion
    error_reporting(0);
    ini_set('display_errors', 0);
}

// --- CONEXION PDO (PRINCIPAL) ---
try {
    $dsn = "mysql:host=$host;port=$port;dbname=$db_name;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $username, $password, $options);

    // Alias para compatibilidad con scripts que usen $conn
    $conn = $pdo;

} catch (PDOException $e) {
    if ($is_local) {
        die("Error de conexion: " . $e->getMessage());
    } else {
        http_response_code(500);
        die(json_encode(["success" => false, "message" => "Error interno del servidor."]));
    }
}
?>
