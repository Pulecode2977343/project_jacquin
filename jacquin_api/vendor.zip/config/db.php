<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "jam_db";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        "error" => "Error en la conexión a la base de datos",
        "details" => $e->getMessage()
    ]);
    exit;
}
