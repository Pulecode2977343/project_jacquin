<?php
// lee todas las líneas .env
$env = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

foreach ($env as $line) {
    list($name, $value) = explode('=', $line, 2);
    putenv("$name=$value");
}

define("ADMIN_SECRET_KEY", "SECRET_ADMIN_KEY_123");
