<?php
// Simple .env parser for native PHP without Composer
function loadEnv($path)
{
    if (!file_exists($path)) {
        return false; // Fail silently or handle error
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue; // Skip comments
        }

        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);

        if (!array_key_exists($name, $_SERVER) && !array_key_exists($name, $_ENV)) {
            putenv(sprintf('%s=%s', $name, $value));
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
    return true;
}

// Intenta cargar desde diferentes ubicaciones posibles sin complicarse
$possiblePaths = [
    __DIR__ . '/../.env',                  // Ubicación estándar: jacquin_api/.env (relative to config/)
    __DIR__ . '/../../.env'                // Raíz del proyecto: project_jacquin/.env
];

foreach ($possiblePaths as $path) {
    if (loadEnv($path)) {
        break; // Detenerse en cuanto encuentre uno
    }
}
