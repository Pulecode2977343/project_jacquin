-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: jam_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about_cards`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about_cards` (
  `id_card` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `subtitle` varchar(150) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_card`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_cards`
--

LOCK TABLES `about_cards` WRITE;
/*!40000 ALTER TABLE `about_cards` DISABLE KEYS */;
INSERT INTO `about_cards` VALUES (1,'Nuestra Historia','Desde 2010','bi-award','Fundada con la visión de democratizar la educación musical de calidad, JACQUIN ha formado a cientos de estudiantes que hoy brillan en escenarios nacionales e internacionales. Nuestra trayectoria nos respalda como una institución comprometida con la excelencia artística.','images/about/historia.jpg',NULL,1,1,'2026-01-09 21:22:14','2026-01-09 21:22:14'),(2,'Nuestro Equipo','Profesionales apasionados','bi-people','Contamos con un equipo de profesores profesionales, músicos activos y pedagogos apasionados que guían a cada estudiante en su camino hacia la excelencia musical. Cada miembro de nuestro equipo trae experiencia y pasión a cada clase.','images/about/equipo.jpg',NULL,2,1,'2026-01-09 21:22:14','2026-01-09 21:22:14'),(3,'Metodología','Enfoque personalizado','bi-music-note-list','Nuestra metodología combina técnica clásica con enfoques modernos, adaptándose al ritmo y estilo de aprendizaje de cada estudiante para garantizar resultados excepcionales. Creemos que cada persona aprende de manera única.','images/about/metodologia.jpg',NULL,3,1,'2026-01-09 21:22:14','2026-01-09 21:22:14'),(4,'Instalaciones','Espacios creativos','bi-house-heart','Espacios creativos diseñados para inspirar. Salones equipados con instrumentos de calidad y tecnología moderna para una experiencia de aprendizaje inmersiva. Cada rincón está pensado para estimular la creatividad.','images/about/instalaciones.jpg','[\"images\\/about\\/instalaciones_sala_piano.jpg\",\"images\\/about\\/instalaciones_estudio.jpg\",\"images\\/about\\/instalaciones_ensayo.jpg\"]',4,1,'2026-01-09 21:22:14','2026-01-09 21:37:26');
/*!40000 ALTER TABLE `about_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `academic_notes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `academic_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `note_type` enum('observation','grade','behavior','achievement') DEFAULT 'observation',
  `score` decimal(5,2) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_private_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`),
  KEY `fk_note_teacher` (`teacher_id`),
  CONSTRAINT `fk_note_student` FOREIGN KEY (`student_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `fk_note_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_notes`
--

LOCK TABLES `academic_notes` WRITE;
/*!40000 ALTER TABLE `academic_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `academic_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late','excused') DEFAULT 'present',
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`schedule_id`,`student_id`,`date`),
  KEY `schedule_id` (`schedule_id`),
  KEY `student_id` (`student_id`),
  KEY `date` (`date`),
  CONSTRAINT `fk_att_student` FOREIGN KEY (`student_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compliance_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compliance_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `media_type` enum('document','image','video','link') DEFAULT 'document',
  `media_url` text DEFAULT NULL,
  `target_role` enum('all','teacher','student') DEFAULT 'all',
  `is_active` tinyint(1) DEFAULT 1,
  `due_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compliance_items`
--

LOCK TABLES `compliance_items` WRITE;
/*!40000 ALTER TABLE `compliance_items` DISABLE KEYS */;
INSERT INTO `compliance_items` VALUES (1,'Certificado de Antecedentes','Todos los docentes deben presentar certificado de antecedentes actualizado','document','https://example.com/doc.pdf','teacher',1,'2026-02-15 00:00:00','2026-01-17 01:23:27');
/*!40000 ALTER TABLE `compliance_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compliance_tracking`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compliance_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compliance_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('pending','viewed','completed') DEFAULT 'pending',
  `completed_at` datetime DEFAULT NULL,
  `proof_url` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compliance_id` (`compliance_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_comp_item` FOREIGN KEY (`compliance_id`) REFERENCES `compliance_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_comp_user` FOREIGN KEY (`user_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compliance_tracking`
--

LOCK TABLES `compliance_tracking` WRITE;
/*!40000 ALTER TABLE `compliance_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `compliance_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_assignments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `media_type` enum('document','image','video','link','none') DEFAULT 'none',
  `media_url` text DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `teacher_id` (`teacher_id`),
  CONSTRAINT `fk_assign_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_assignments`
--

LOCK TABLES `course_assignments` WRITE;
/*!40000 ALTER TABLE `course_assignments` DISABLE KEYS */;
INSERT INTO `course_assignments` VALUES (1,15,3,'el pentagrama','dibuja un pentagrama con la clave de F','none','','2026-01-30 00:00:00',1,'2026-01-24 00:35:55');
/*!40000 ALTER TABLE `course_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id_course` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_course`),
  KEY `fk_course_teacher` (`teacher_id`),
  CONSTRAINT `fk_course_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (9,'Percusión','Ritmo y energía. Batería, timac, congas y más.',NULL,NULL,'2025-12-19 04:41:55'),(10,'Guitarra','Guitarra Acústica y Eléctrica. Técnica y Repertorio.',NULL,NULL,'2025-12-19 04:41:55'),(11,'Piano','Piano Clásico y Moderno. Lectura y Técnica.',NULL,NULL,'2025-12-19 04:41:55'),(12,'Voz','Técnica Vocal. Canto popular y lírico.',NULL,NULL,'2025-12-19 04:41:55'),(13,'Senior\'s','Programa especial para el Adulto Mayor.',NULL,NULL,'2025-12-19 04:41:55'),(14,'Shows','Presentaciones en vivo y ensambles.',NULL,NULL,'2025-12-19 04:41:55'),(15,'Exploración','Iniciación Musical para niños.',3,NULL,'2025-12-19 04:41:55'),(16,'Psicomúsica','Bienestar y Terapia a través de la música.',NULL,NULL,'2025-12-19 04:41:55'),(17,'Instalaciones','Espacios Creativos.',NULL,NULL,'2025-12-19 04:41:55'),(998,'Curso Test A','Desc',NULL,NULL,'2026-01-23 17:25:27'),(999,'Curso Test B','Desc',NULL,NULL,'2026-01-23 17:25:27');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment_schedules`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollment_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enrollment_id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_enrollment_schedule` (`enrollment_id`,`schedule_id`),
  KEY `idx_enrollment` (`enrollment_id`),
  KEY `idx_schedule` (`schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment_schedules`
--

LOCK TABLES `enrollment_schedules` WRITE;
/*!40000 ALTER TABLE `enrollment_schedules` DISABLE KEYS */;
INSERT INTO `enrollment_schedules` VALUES (1,34,147,'2026-01-09 21:20:28'),(3,43,73,'2026-01-16 00:04:59'),(4,46,146,'2026-01-16 00:33:42'),(5,47,149,'2026-01-16 00:40:44'),(6,48,150,'2026-01-16 00:44:58'),(7,49,153,'2026-01-16 00:44:58'),(8,50,154,'2026-01-16 00:44:59'),(9,51,157,'2026-01-16 00:44:59'),(10,52,158,'2026-01-16 00:44:59'),(11,53,161,'2026-01-16 00:44:59'),(12,54,162,'2026-01-16 00:44:59'),(13,55,49,'2026-01-16 00:46:32'),(14,56,52,'2026-01-16 00:46:32'),(15,57,55,'2026-01-16 00:46:32'),(16,58,56,'2026-01-16 00:46:32'),(17,59,59,'2026-01-16 00:46:32'),(18,60,63,'2026-01-16 00:46:33'),(19,61,64,'2026-01-16 00:46:33'),(20,62,67,'2026-01-16 00:46:33'),(21,63,68,'2026-01-16 00:46:33'),(22,64,145,'2026-01-16 21:12:39'),(23,65,146,'2026-01-16 21:15:11'),(24,66,149,'2026-01-16 21:16:01'),(25,67,150,'2026-01-16 21:40:49'),(26,68,153,'2026-01-16 21:40:49'),(27,69,154,'2026-01-16 21:40:49'),(28,70,157,'2026-01-16 21:40:49'),(29,71,158,'2026-01-16 21:40:50'),(30,72,161,'2026-01-16 21:40:50'),(31,73,162,'2026-01-16 21:40:50'),(32,74,165,'2026-01-16 21:40:50'),(33,75,166,'2026-01-16 21:40:51'),(35,76,145,'2026-01-17 23:50:37'),(36,77,59,'2026-01-17 23:51:00'),(37,35,54,'2026-01-20 23:50:49'),(38,78,149,'2026-01-20 23:54:39'),(39,79,50,'2026-01-21 00:15:05'),(40,80,146,'2026-01-21 17:32:13'),(42,81,153,'2026-01-21 19:35:10'),(44,82,148,'2026-01-21 19:50:47'),(45,82,152,'2026-01-21 19:50:47'),(47,83,149,'2026-01-21 19:58:17'),(48,84,145,'2026-01-21 22:43:15'),(49,84,149,'2026-01-21 22:49:29'),(50,84,153,'2026-01-21 22:53:50'),(51,84,157,'2026-01-21 22:55:05'),(52,85,2,'2026-01-21 22:59:54'),(53,86,145,'2026-01-22 18:37:29'),(54,87,25,'2026-01-23 16:56:33'),(55,91,145,'2026-01-24 00:26:11'),(56,92,145,'2026-01-24 00:27:03'),(57,93,145,'2026-01-24 00:27:45');
/*!40000 ALTER TABLE `enrollment_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollments` (
  `id_enrollment` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Activo','Completado','Cancelado','Pendiente','Pre-inscrito') DEFAULT 'Pendiente',
  PRIMARY KEY (`id_enrollment`),
  UNIQUE KEY `unique_enrollment_schedule` (`student_id`,`course_id`,`schedule_id`),
  KEY `fk_enrollment_student` (`student_id`),
  KEY `fk_enrollment_course` (`course_id`),
  CONSTRAINT `fk_enrollment_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id_course`) ON DELETE CASCADE,
  CONSTRAINT `fk_enrollment_student` FOREIGN KEY (`student_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES (35,20,11,NULL,'2026-01-10 01:29:43',''),(43,4,12,73,'2026-01-15 23:23:13',''),(76,32,15,NULL,'2026-01-17 17:50:23',''),(77,33,11,NULL,'2026-01-17 18:11:13',''),(81,32,15,149,'2026-01-21 18:27:08',''),(82,32,15,148,'2026-01-21 19:36:03',''),(83,32,15,146,'2026-01-21 19:58:04',''),(84,32,15,145,'2026-01-21 22:43:15','Activo'),(86,29,15,145,'2026-01-22 18:37:29','Activo'),(87,29,10,25,'2026-01-23 16:56:33','Activo'),(90,35,998,9998,'2026-01-23 17:26:16','Activo'),(91,35,15,145,'2026-01-24 00:26:11','Activo'),(92,33,15,145,'2026-01-24 00:27:03','Activo'),(93,20,15,145,'2026-01-24 00:27:45','Activo');
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_reservations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_reservations` (
  `id_reservation` int(11) NOT NULL AUTO_INCREMENT,
  `id_event` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `guest_name` varchar(100) DEFAULT NULL,
  `guest_email` varchar(100) DEFAULT NULL,
  `guest_phone` varchar(20) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_reservation`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_reservations`
--

LOCK TABLES `event_reservations` WRITE;
/*!40000 ALTER TABLE `event_reservations` DISABLE KEYS */;
INSERT INTO `event_reservations` VALUES (1,4,6,'Adrian Delgado','manuel.delgado@gmail.com','','pending','2026-01-08 02:05:54'),(2,5,6,'Adrian Delgado','manuel.delgado@gmail.com','','pending','2026-01-08 02:08:05');
/*!40000 ALTER TABLE `event_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id_event` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` time DEFAULT NULL,
  `event_type` enum('concierto','recital','taller','masterclass','presentacion','otro') DEFAULT 'otro',
  `location` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT 0.00,
  `image_url` varchar(500) DEFAULT NULL,
  `media_type` enum('imagen','video_youtube','video_nativo','pdf','ppt','ninguno') DEFAULT 'ninguno',
  `media_url` varchar(500) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_event`),
  KEY `idx_date` (`event_date`),
  KEY `idx_featured` (`is_featured`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Concierto de Gala 2026 [Updated]','Evento anual de fin de año con todos los estudiantes.','2026-12-15','19:00:00','recital','Teatro Santa Marta',35000.00,'uploads/events/event_1_1767764578_img.png','video_youtube','https://youtu.be/v6IWGbkmPl8?si=TJ0eIgKcCwmScX_T',1,0,'2026-01-07 04:14:24','2026-01-07 19:16:03'),(2,'Masterclass de Violín con Sarah Chang','Una oportunidad única para aprender de una de las violinistas más aclamadas del mundo. Dirigido a estudiantes avanzados del conservatorio y músicos externos.','2026-02-15','14:00:00','masterclass','Auditorio Principal Jacquin',150000.00,'uploads/events/event_2_1767765019_img.png','ninguno',NULL,1,1,'2026-01-07 04:56:51','2026-01-07 05:50:19'),(3,'Recital de Piano: Clásicos del Siglo XX','Interpretación de obras maestras de Debussy, Ravel y Prokofiev por los estudiantes más destacados de la cátedra de piano.','2026-03-10','18:30:00','recital','Sala de Cámara',20000.00,'uploads/events/event_3_1767764952_img.png','ninguno',NULL,0,1,'2026-01-07 04:56:51','2026-01-07 05:49:12'),(4,'Taller de Improvisación Jazz','Explora las técnicas de improvisación, escalas y armonía moderna en este taller intensivo. Abierto a todos los instrumentos.','2026-03-25','10:00:00','taller','Sala 204',50000.00,'uploads/events/event_4_1767765535_img.png','ninguno',NULL,0,1,'2026-01-07 04:56:51','2026-01-07 05:58:55'),(5,'Concierto de Temporada: Orquesta Sinfónica','La Orquesta Sinfónica Jacquin presenta su primer gran concierto de la temporada 2026, interpretando la Sinfonía No. 5 de Beethoven.','2026-04-05','19:00:00','concierto','Teatro Santa Marta',30000.00,'uploads/events/event_5_1767765443_img.png','video_youtube','',1,1,'2026-01-07 04:56:51','2026-01-07 05:57:23'),(6,'Presentación de Ensamble de Cuerdas','Muestra semestral de los ensambles de cuerdas frotadas (violín, viola, cello, contrabajo) con un repertorio que abarca desde el barroco hasta el romanticismo.','2026-04-20','19:00:00','presentacion','Auditorio Principal Jacquin',0.00,'uploads/events/event_6_1767764423_img.png','ninguno',NULL,0,1,'2026-01-07 04:56:51','2026-01-07 05:40:47'),(7,'Clausura 2025!','Concierto a cargo de los estudiantes','2025-12-22','16:24:00','otro','Teatro CAJAMAG',0.00,'uploads/events/event_1767810287_img.png','ninguno',NULL,0,1,'2026-01-07 18:24:47','2026-01-07 18:24:47'),(8,'Clausura 2026','concierto','2025-12-22','16:47:00','concierto','Teatro CAJAMAG',0.00,'uploads/events/event_1767811683_img.png','ninguno',NULL,0,1,'2026-01-07 18:48:03','2026-01-07 18:48:03'),(9,'Clausura 2026','concierto','2025-12-22','16:16:00','presentacion','Teatro CAJAMAG',0.00,'uploads/events/event_1767813403_img.png','ninguno',NULL,0,0,'2026-01-07 19:16:43','2026-01-07 19:53:31'),(10,'Masterclass de Contrabajo','Masterclass','2026-01-30','17:54:00','otro','Auditorio Principal Jacquin',0.00,'uploads/events/event_1767815683_img.png','ninguno',NULL,0,1,'2026-01-07 19:54:43','2026-01-07 19:54:43'),(11,'Curso Pre-Universitario de Música','Prepárate para la excelencia musical. Curso intensivo de 4 meses (16 semanas) enfocado en piano, solfeo y teoría musical. Certificado incluído. ¡Ideal para tu examen de admisión!','2026-03-02','00:00:00','masterclass','Auditorio Principal Jacquin',200000.00,'uploads/events/event_1768093034_img.png','ninguno',NULL,1,1,'2026-01-11 00:57:14','2026-01-11 00:57:14');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('Instrumento','Equipo','Accesorio','Otro') NOT NULL,
  `serial` varchar(50) DEFAULT NULL,
  `estado` enum('Nuevo','Bueno','Regular','Malo') DEFAULT 'Bueno',
  `fecha_adquisicion` date DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `category` enum('Instrumento','Equipo de Audio','Mobiliario','Accesorio','Otro') NOT NULL,
  `serial_number` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `status` enum('Disponible','En uso','En reparación','Dañado/Baja') DEFAULT 'Disponible',
  `purchase_date` date DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position_functions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position_functions` (
  `id_function` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id_function`),
  KEY `position_id` (`position_id`),
  CONSTRAINT `position_functions_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id_position`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position_functions`
--

LOCK TABLES `position_functions` WRITE;
/*!40000 ALTER TABLE `position_functions` DISABLE KEYS */;
INSERT INTO `position_functions` VALUES (1,1,'Planificar clases',1,1),(2,1,'Impartir clases',1,2),(3,1,'Evaluar estudiantes',1,3),(4,2,'Atención al público',1,1),(5,2,'Gestión de llamadas',1,2),(6,2,'Matrículas',1,3),(7,3,'Control inventario',1,1),(8,3,'Montaje eventos',1,2),(9,4,'Limpieza',1,1),(10,4,'Mantenimiento básico',1,2),(11,1,'Planificar clases',1,1),(12,1,'Impartir clases',1,2),(13,1,'Evaluar estudiantes',1,3),(14,2,'Atención al público',1,1),(15,2,'Gestión de llamadas',1,2),(16,2,'Matrículas',1,3),(17,3,'Control inventario',1,1),(18,3,'Montaje eventos',1,2),(19,4,'Limpieza',1,1),(20,4,'Mantenimiento básico',1,2);
/*!40000 ALTER TABLE `position_functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id_position` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(20) DEFAULT '?',
  `description` varchar(255) DEFAULT NULL,
  `is_predefined` tinyint(1) DEFAULT 0,
  `is_visible` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_position`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'Profesor','👨‍🏫','Docente encargado de impartir clases y evaluar estudiantes',1,1,'2026-01-21 23:27:00',NULL),(2,'Secretario','📋','Personal administrativo de recepción y atención al público',1,1,'2026-01-21 23:27:00',NULL),(3,'Logística','📦','Encargado de inventario, equipos y recursos de la academia',1,1,'2026-01-21 23:27:00',NULL),(4,'Servicios Generales','🧹','Personal de mantenimiento, limpieza y apoyo general',1,1,'2026-01-21 23:27:00',NULL),(5,'Cafetería','????','* administrar inventario de cafetería.\n* Atención de punto de venta\n*Informar por medio del aplicativo las neesidades del servicio.',0,1,'2026-01-21 23:41:44',4);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'Administrador'),(2,'Docente'),(3,'Estudiante'),(4,'Aspirante'),(5,'Colaborador');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_requests`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `requested_day` varchar(20) NOT NULL,
  `requested_time` time NOT NULL,
  `status` enum('pending','approved','rejected','modified') DEFAULT 'pending',
  `admin_response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `schedule_requests_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `schedule_requests_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id_course`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_requests`
--

LOCK TABLES `schedule_requests` WRITE;
/*!40000 ALTER TABLE `schedule_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id_schedule` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `quota` int(11) DEFAULT 20,
  `teacher_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_schedule`),
  UNIQUE KEY `unique_schedule` (`id_course`,`day`,`time_start`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`id_course`) REFERENCES `courses` (`id_course`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,9,'Lunes','15:00:00','15:45:00',15,NULL),(2,9,'Lunes','15:45:00','16:30:00',15,NULL),(3,9,'Lunes','16:30:00','17:15:00',15,NULL),(4,9,'Lunes','17:15:00','18:00:00',15,NULL),(5,9,'Martes','15:00:00','15:45:00',15,NULL),(6,9,'Martes','15:45:00','16:30:00',15,NULL),(7,9,'Martes','16:30:00','17:15:00',15,NULL),(8,9,'Martes','17:15:00','18:00:00',15,NULL),(9,9,'Miércoles','15:00:00','15:45:00',15,NULL),(10,9,'Miércoles','15:45:00','16:30:00',15,NULL),(11,9,'Miércoles','16:30:00','17:15:00',15,NULL),(12,9,'Miércoles','17:15:00','18:00:00',15,NULL),(13,9,'Jueves','15:00:00','15:45:00',15,NULL),(14,9,'Jueves','15:45:00','16:30:00',15,NULL),(15,9,'Jueves','16:30:00','17:15:00',15,NULL),(16,9,'Jueves','17:15:00','18:00:00',15,NULL),(17,9,'Viernes','15:00:00','15:45:00',15,NULL),(18,9,'Viernes','15:45:00','16:30:00',15,NULL),(19,9,'Viernes','16:30:00','17:15:00',15,NULL),(20,9,'Viernes','17:15:00','18:00:00',15,NULL),(21,9,'Sábado','09:00:00','09:45:00',15,NULL),(22,9,'Sábado','09:45:00','10:30:00',15,NULL),(23,9,'Sábado','10:30:00','11:15:00',15,NULL),(24,9,'Sábado','11:15:00','12:00:00',15,NULL),(25,10,'Lunes','15:00:00','15:45:00',15,NULL),(26,10,'Lunes','15:45:00','16:30:00',15,NULL),(27,10,'Lunes','16:30:00','17:15:00',15,NULL),(28,10,'Lunes','17:15:00','18:00:00',15,NULL),(29,10,'Martes','15:00:00','15:45:00',15,NULL),(30,10,'Martes','15:45:00','16:30:00',15,NULL),(31,10,'Martes','16:30:00','17:15:00',15,NULL),(32,10,'Martes','17:15:00','18:00:00',15,NULL),(33,10,'Miércoles','15:00:00','15:45:00',15,NULL),(34,10,'Miércoles','15:45:00','16:30:00',15,NULL),(35,10,'Miércoles','16:30:00','17:15:00',15,NULL),(36,10,'Miércoles','17:15:00','18:00:00',15,NULL),(37,10,'Jueves','15:00:00','15:45:00',15,NULL),(38,10,'Jueves','15:45:00','16:30:00',15,NULL),(39,10,'Jueves','16:30:00','17:15:00',15,NULL),(40,10,'Jueves','17:15:00','18:00:00',15,NULL),(41,10,'Viernes','15:00:00','15:45:00',15,NULL),(42,10,'Viernes','15:45:00','16:30:00',15,NULL),(43,10,'Viernes','16:30:00','17:15:00',15,NULL),(44,10,'Viernes','17:15:00','18:00:00',15,NULL),(45,10,'Sábado','09:00:00','09:45:00',15,NULL),(46,10,'Sábado','09:45:00','10:30:00',15,NULL),(47,10,'Sábado','10:30:00','11:15:00',15,NULL),(48,10,'Sábado','11:15:00','12:00:00',15,NULL),(49,11,'Lunes','15:00:00','15:45:00',15,NULL),(50,11,'Lunes','15:45:00','16:30:00',15,NULL),(51,11,'Lunes','16:30:00','17:15:00',15,NULL),(52,11,'Lunes','17:15:00','18:00:00',15,NULL),(53,11,'Martes','15:00:00','15:45:00',15,NULL),(54,11,'Martes','15:45:00','16:30:00',15,NULL),(55,11,'Martes','16:30:00','17:15:00',15,NULL),(56,11,'Martes','17:15:00','18:00:00',15,NULL),(57,11,'Miércoles','15:00:00','15:45:00',15,NULL),(58,11,'Miércoles','15:45:00','16:30:00',15,NULL),(59,11,'Miércoles','16:30:00','17:15:00',15,NULL),(60,11,'Miércoles','17:15:00','18:00:00',15,NULL),(61,11,'Jueves','15:00:00','15:45:00',15,NULL),(62,11,'Jueves','15:45:00','16:30:00',15,NULL),(63,11,'Jueves','16:30:00','17:15:00',15,NULL),(64,11,'Jueves','17:15:00','18:00:00',15,NULL),(65,11,'Viernes','15:00:00','15:45:00',15,NULL),(66,11,'Viernes','15:45:00','16:30:00',15,NULL),(67,11,'Viernes','16:30:00','17:15:00',15,NULL),(68,11,'Viernes','17:15:00','18:00:00',15,NULL),(69,11,'Sábado','09:00:00','09:45:00',15,NULL),(70,11,'Sábado','09:45:00','10:30:00',15,NULL),(71,11,'Sábado','10:30:00','11:15:00',15,NULL),(72,11,'Sábado','11:15:00','12:00:00',15,NULL),(73,12,'Lunes','15:00:00','15:45:00',15,NULL),(74,12,'Lunes','15:45:00','16:30:00',15,NULL),(75,12,'Lunes','16:30:00','17:15:00',15,NULL),(76,12,'Lunes','17:15:00','18:00:00',15,NULL),(77,12,'Martes','15:00:00','15:45:00',15,NULL),(78,12,'Martes','15:45:00','16:30:00',15,NULL),(79,12,'Martes','16:30:00','17:15:00',15,NULL),(80,12,'Martes','17:15:00','18:00:00',15,NULL),(81,12,'Miércoles','15:00:00','15:45:00',15,NULL),(82,12,'Miércoles','15:45:00','16:30:00',15,NULL),(83,12,'Miércoles','16:30:00','17:15:00',15,NULL),(84,12,'Miércoles','17:15:00','18:00:00',15,NULL),(85,12,'Jueves','15:00:00','15:45:00',15,NULL),(86,12,'Jueves','15:45:00','16:30:00',15,NULL),(87,12,'Jueves','16:30:00','17:15:00',15,NULL),(88,12,'Jueves','17:15:00','18:00:00',15,NULL),(89,12,'Viernes','15:00:00','15:45:00',15,NULL),(90,12,'Viernes','15:45:00','16:30:00',15,NULL),(91,12,'Viernes','16:30:00','17:15:00',15,NULL),(92,12,'Viernes','17:15:00','18:00:00',15,NULL),(93,12,'Sábado','09:00:00','09:45:00',15,NULL),(94,12,'Sábado','09:45:00','10:30:00',15,NULL),(95,12,'Sábado','10:30:00','11:15:00',15,NULL),(96,12,'Sábado','11:15:00','12:00:00',15,NULL),(97,13,'Lunes','15:00:00','15:45:00',15,NULL),(98,13,'Lunes','15:45:00','16:30:00',15,NULL),(99,13,'Lunes','16:30:00','17:15:00',15,NULL),(100,13,'Lunes','17:15:00','18:00:00',15,NULL),(101,13,'Martes','15:00:00','15:45:00',15,NULL),(102,13,'Martes','15:45:00','16:30:00',15,NULL),(103,13,'Martes','16:30:00','17:15:00',15,NULL),(104,13,'Martes','17:15:00','18:00:00',15,NULL),(105,13,'Miércoles','15:00:00','15:45:00',15,NULL),(106,13,'Miércoles','15:45:00','16:30:00',15,NULL),(107,13,'Miércoles','16:30:00','17:15:00',15,NULL),(108,13,'Miércoles','17:15:00','18:00:00',15,NULL),(109,13,'Jueves','15:00:00','15:45:00',15,NULL),(110,13,'Jueves','15:45:00','16:30:00',15,NULL),(111,13,'Jueves','16:30:00','17:15:00',15,NULL),(112,13,'Jueves','17:15:00','18:00:00',15,NULL),(113,13,'Viernes','15:00:00','15:45:00',15,NULL),(114,13,'Viernes','15:45:00','16:30:00',15,NULL),(115,13,'Viernes','16:30:00','17:15:00',15,NULL),(116,13,'Viernes','17:15:00','18:00:00',15,NULL),(117,13,'Sábado','09:00:00','09:45:00',15,NULL),(118,13,'Sábado','09:45:00','10:30:00',15,NULL),(119,13,'Sábado','10:30:00','11:15:00',15,NULL),(120,13,'Sábado','11:15:00','12:00:00',15,NULL),(121,14,'Lunes','15:00:00','15:45:00',15,NULL),(122,14,'Lunes','15:45:00','16:30:00',15,NULL),(123,14,'Lunes','16:30:00','17:15:00',15,NULL),(124,14,'Lunes','17:15:00','18:00:00',15,NULL),(125,14,'Martes','15:00:00','15:45:00',15,NULL),(126,14,'Martes','15:45:00','16:30:00',15,NULL),(127,14,'Martes','16:30:00','17:15:00',15,NULL),(128,14,'Martes','17:15:00','18:00:00',15,NULL),(129,14,'Miércoles','15:00:00','15:45:00',15,NULL),(130,14,'Miércoles','15:45:00','16:30:00',15,NULL),(131,14,'Miércoles','16:30:00','17:15:00',15,NULL),(132,14,'Miércoles','17:15:00','18:00:00',15,NULL),(133,14,'Jueves','15:00:00','15:45:00',15,NULL),(134,14,'Jueves','15:45:00','16:30:00',15,NULL),(135,14,'Jueves','16:30:00','17:15:00',15,NULL),(136,14,'Jueves','17:15:00','18:00:00',15,NULL),(137,14,'Viernes','15:00:00','15:45:00',15,NULL),(138,14,'Viernes','15:45:00','16:30:00',15,NULL),(139,14,'Viernes','16:30:00','17:15:00',15,NULL),(140,14,'Viernes','17:15:00','18:00:00',15,NULL),(141,14,'Sábado','09:00:00','09:45:00',15,NULL),(142,14,'Sábado','09:45:00','10:30:00',15,NULL),(143,14,'Sábado','10:30:00','11:15:00',15,NULL),(144,14,'Sábado','11:15:00','12:00:00',15,NULL),(145,15,'Lunes','15:00:00','15:45:00',15,NULL),(146,15,'Lunes','15:45:00','16:30:00',15,31),(147,15,'Lunes','16:30:00','17:15:00',15,NULL),(148,15,'Lunes','17:15:00','18:00:00',15,31),(149,15,'Martes','15:00:00','15:45:00',15,NULL),(150,15,'Martes','15:45:00','16:30:00',15,NULL),(151,15,'Martes','16:30:00','17:15:00',15,NULL),(152,15,'Martes','17:15:00','18:00:00',15,NULL),(153,15,'Miércoles','15:00:00','15:45:00',15,NULL),(154,15,'Miércoles','15:45:00','16:30:00',15,NULL),(155,15,'Miércoles','16:30:00','17:15:00',15,NULL),(156,15,'Miércoles','17:15:00','18:00:00',15,NULL),(157,15,'Jueves','15:00:00','15:45:00',15,NULL),(158,15,'Jueves','15:45:00','16:30:00',15,NULL),(159,15,'Jueves','16:30:00','17:15:00',15,NULL),(160,15,'Jueves','17:15:00','18:00:00',15,NULL),(161,15,'Viernes','15:00:00','15:45:00',15,NULL),(162,15,'Viernes','15:45:00','16:30:00',15,NULL),(163,15,'Viernes','16:30:00','17:15:00',15,NULL),(164,15,'Viernes','17:15:00','18:00:00',15,NULL),(165,15,'Sábado','09:00:00','09:45:00',15,NULL),(166,15,'Sábado','09:45:00','10:30:00',15,NULL),(167,15,'Sábado','10:30:00','11:15:00',15,NULL),(168,15,'Sábado','11:15:00','12:00:00',15,NULL),(169,16,'Lunes','15:00:00','15:45:00',15,NULL),(170,16,'Lunes','15:45:00','16:30:00',15,NULL),(171,16,'Lunes','16:30:00','17:15:00',15,NULL),(172,16,'Lunes','17:15:00','18:00:00',15,NULL),(173,16,'Martes','15:00:00','15:45:00',15,NULL),(174,16,'Martes','15:45:00','16:30:00',15,NULL),(175,16,'Martes','16:30:00','17:15:00',15,NULL),(176,16,'Martes','17:15:00','18:00:00',15,NULL),(177,16,'Miércoles','15:00:00','15:45:00',15,NULL),(178,16,'Miércoles','15:45:00','16:30:00',15,NULL),(179,16,'Miércoles','16:30:00','17:15:00',15,NULL),(180,16,'Miércoles','17:15:00','18:00:00',15,NULL),(181,16,'Jueves','15:00:00','15:45:00',15,NULL),(182,16,'Jueves','15:45:00','16:30:00',15,NULL),(183,16,'Jueves','16:30:00','17:15:00',15,NULL),(184,16,'Jueves','17:15:00','18:00:00',15,NULL),(185,16,'Viernes','15:00:00','15:45:00',15,NULL),(186,16,'Viernes','15:45:00','16:30:00',15,NULL),(187,16,'Viernes','16:30:00','17:15:00',15,NULL),(188,16,'Viernes','17:15:00','18:00:00',15,NULL),(189,16,'Sábado','09:00:00','09:45:00',15,NULL),(190,16,'Sábado','09:45:00','10:30:00',15,NULL),(191,16,'Sábado','10:30:00','11:15:00',15,NULL),(192,16,'Sábado','11:15:00','12:00:00',15,NULL),(193,17,'Lunes','15:00:00','15:45:00',15,NULL),(194,17,'Lunes','15:45:00','16:30:00',15,NULL),(195,17,'Lunes','16:30:00','17:15:00',15,NULL),(196,17,'Lunes','17:15:00','18:00:00',15,NULL),(197,17,'Martes','15:00:00','15:45:00',15,NULL),(198,17,'Martes','15:45:00','16:30:00',15,NULL),(199,17,'Martes','16:30:00','17:15:00',15,NULL),(200,17,'Martes','17:15:00','18:00:00',15,NULL),(201,17,'Miércoles','15:00:00','15:45:00',15,NULL),(202,17,'Miércoles','15:45:00','16:30:00',15,NULL),(203,17,'Miércoles','16:30:00','17:15:00',15,NULL),(204,17,'Miércoles','17:15:00','18:00:00',15,NULL),(205,17,'Jueves','15:00:00','15:45:00',15,NULL),(206,17,'Jueves','15:45:00','16:30:00',15,NULL),(207,17,'Jueves','16:30:00','17:15:00',15,NULL),(208,17,'Jueves','17:15:00','18:00:00',15,NULL),(209,17,'Viernes','15:00:00','15:45:00',15,NULL),(210,17,'Viernes','15:45:00','16:30:00',15,NULL),(211,17,'Viernes','16:30:00','17:15:00',15,NULL),(212,17,'Viernes','17:15:00','18:00:00',15,NULL),(213,17,'Sábado','09:00:00','09:45:00',15,NULL),(214,17,'Sábado','09:45:00','10:30:00',15,NULL),(215,17,'Sábado','10:30:00','11:15:00',15,NULL),(216,17,'Sábado','11:15:00','12:00:00',15,NULL),(9998,998,'Lunes','10:00:00','11:00:00',20,NULL),(9999,999,'Lunes','10:30:00','11:30:00',20,NULL);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_submissions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `submission_text` text DEFAULT NULL,
  `submission_url` text DEFAULT NULL,
  `status` enum('pending','submitted','graded','late') DEFAULT 'pending',
  `grade` decimal(5,2) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `graded_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_submission` (`assignment_id`,`student_id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `fk_sub_assign` FOREIGN KEY (`assignment_id`) REFERENCES `course_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sub_student` FOREIGN KEY (`student_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_submissions`
--

LOCK TABLES `student_submissions` WRITE;
/*!40000 ALTER TABLE `student_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_functions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_functions` (
  `id_function` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL COMMENT 'Ej: Director de Orquesta, Jefe de Cuerdas',
  `description` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id_function`),
  KEY `fk_function_teacher` (`teacher_id`),
  CONSTRAINT `fk_function_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_functions`
--

LOCK TABLES `teacher_functions` WRITE;
/*!40000 ALTER TABLE `teacher_functions` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_positions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `notified` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_position` (`user_id`,`position_id`),
  KEY `position_id` (`position_id`),
  CONSTRAINT `user_positions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `user_positions_ibfk_2` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id_position`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_positions`
--

LOCK TABLES `user_positions` WRITE;
/*!40000 ALTER TABLE `user_positions` DISABLE KEYS */;
INSERT INTO `user_positions` VALUES (1,30,3,4,'2026-01-22 01:02:33',1,0),(2,34,3,4,'2026-01-22 01:17:03',1,0),(3,31,1,4,'2026-01-22 01:12:07',1,0),(4,3,1,4,'2026-01-22 01:16:55',1,0),(5,34,5,4,'2026-01-22 01:24:25',1,0),(6,31,3,4,'2026-01-24 00:15:58',1,0);
/*!40000 ALTER TABLE `user_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `recovery_code` varchar(6) DEFAULT NULL,
  `recovery_expires` datetime DEFAULT NULL,
  `n_phone` varchar(20) DEFAULT NULL,
  `id_rol` int(11) NOT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_usuario_rol` (`id_rol`),
  CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (3,'Pule Colombia In','manuel78pertuz@gmail.com','$2y$10$qkUmxyT6oK.OsFiAIWF/RuBLmNqspsW3fOrmiiV1vzJksI1AYSmme',NULL,NULL,'3132576302',2,'uploads/avatars/avatar_3_1766464755.png','2025-12-19 02:47:27'),(4,'Visionary Code Team','visionarycode.team@gmail.com','$2y$10$22Vqb2uCHyczCAoAg9ZAdurftrR0vGB6chVkr4Ee6.J54jdP/0NwS',NULL,NULL,'+572354684572',1,'uploads/avatars/avatar_4_1767578041.png','2025-12-19 03:14:21'),(20,'veronica triviño','veronica@gmail.com','$2y$10$qkUmxyT6oK.OsFiAIWF/RuBLmNqspsW3fOrmiiV1vzJksI1AYSmme',NULL,NULL,'3143135139',3,NULL,'2026-01-10 01:29:43'),(29,'Erick Pertuz Joya','familia.pertuz.bernal@gmail.com','$2y$10$W/9jvDeC.l53gj94DRX55O78hNkxfuyEXfWeyQBYUoaW7oDYX30wu',NULL,NULL,'3132576302',3,'uploads/avatars/avatar_29_1769562836.png','2026-01-16 20:26:02'),(30,'Administrador JAM','admin@jacquin.edu.co','$2y$10$V7rsyXBLmvbSQqY0HkrwiOoNIBKzqP3Pfh.fOULRqiGLH4Dfuw5GK',NULL,NULL,NULL,1,NULL,'2026-01-17 01:03:04'),(31,'Profesor Demo','profesor@jacquin.edu.co','$2y$10$XckwAqr4LhdpDuX2.2AEZOwYv3bw5oZV5doSKvlLuTliS5ICFRC.2',NULL,NULL,NULL,2,NULL,'2026-01-17 01:28:59'),(32,'Test Student','test_student@test.com','$2y$10$Ti7F4KnjBOkJJlfxBkrYROsJ3MrppxSZ9D.RXpBs7.JZjZh6cPBF.',NULL,NULL,'1234567890',3,NULL,'2026-01-17 17:50:23'),(33,'Test Estudiante','','$2y$10$koIG4boz0mQ7m3MUDcOQ9.7zieH/o.qgmIYpGnZRzrVyiH0CrP5fG',NULL,NULL,'',3,'uploads/avatars/avatar_33_1768876847.png','2026-01-17 18:11:13'),(34,'Colaborador Demo','colaboradordemo@testmail.com','$2y$10$O2cHac8fw44Midip8rLQA.RSCDGy.ptmp5YW9T4/YVGd6CQGgbo.m',NULL,NULL,'',5,NULL,'2026-01-21 02:30:33'),(35,'Estudiante de Prueba','test_estudiante@gmail.com','$2y$10$AodyTyb78ZA5S2DWDwevN.uncdKkCSOQdNN/hSakjteHZ01.6UGli',NULL,NULL,NULL,3,NULL,'2026-01-23 17:24:25');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_mission`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_mission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT 'Nuestra Misión',
  `description` text DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_mission`
--

LOCK TABLES `web_mission` WRITE;
/*!40000 ALTER TABLE `web_mission` DISABLE KEYS */;
INSERT INTO `web_mission` VALUES (1,'Nuestra Misión','Formar músicos integrales con sólidas bases técnicas y artísticas, fomentando la creatividad, la disciplina y el amor por la música.','2026-01-19 23:24:27');
/*!40000 ALTER TABLE `web_mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_values`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_values`
--

LOCK TABLES `web_values` WRITE;
/*!40000 ALTER TABLE `web_values` DISABLE KEYS */;
INSERT INTO `web_values` VALUES (1,'Excelencia','Compromiso con la calidad en cada clase','bi-star','images/values/excelencia.png',1,1),(2,'Pasión','Amor genuino por la música y la enseñanza','bi-heart','images/values/pasion.png',2,1),(3,'Innovación','Métodos actualizados y tecnología educativa','bi-lightbulb','images/values/innovacion.png',3,1),(4,'Respeto','Ambiente inclusivo y de apoyo mutuo','bi-hand-thumbs-up','images/values/respeto.png',4,1);
/*!40000 ALTER TABLE `web_values` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-28 19:50:21
