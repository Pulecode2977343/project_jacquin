<?php
/**
 * helpers/email.php
 * Envío de emails con Brevo (sin imprimir nada, sin json_encode).
 *
 * IMPORTANTE:
 * - No uses echo/print aquí.
 * - No devuelvas JSON aquí.
 * - Solo retorna true/false (o lanza excepción) para que el endpoint responda JSON limpio.
 */
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use Brevo\Client\Api\TransactionalEmailsApi;
use Brevo\Client\ApiException;
use Brevo\Client\Configuration;

/**
 * Obtiene API key de forma segura.
 * - Preferido: define('BREVO_API_KEY', '...') en config/env.php
 * - Alternativa: variable de entorno BREVO_API_KEY
 */
function brevo_api_key(): string
{
    if (defined('BREVO_API_KEY') && is_string(BREVO_API_KEY) && BREVO_API_KEY !== '') {
        return BREVO_API_KEY;
    }

    $env = getenv('BREVO_API_KEY');
    if (is_string($env) && trim($env) !== '') {
        return trim($env);
    }

    throw new RuntimeException('BREVO_API_KEY no está configurada.');
}

function brevo_sender_email(): string
{
    if (defined('BREVO_SENDER_EMAIL') && is_string(BREVO_SENDER_EMAIL) && BREVO_SENDER_EMAIL !== '') {
        return BREVO_SENDER_EMAIL;
    }
    $env = getenv('BREVO_SENDER_EMAIL');
    return is_string($env) && trim($env) !== '' ? trim($env) : 'visionarycode.team@gmail.com';
}

function brevo_sender_name(): string
{
    if (defined('BREVO_SENDER_NAME') && is_string(BREVO_SENDER_NAME) && BREVO_SENDER_NAME !== '') {
        return BREVO_SENDER_NAME;
    }
    $env = getenv('BREVO_SENDER_NAME');
    return is_string($env) && trim($env) !== '' ? trim($env) : 'Jacquin Academia Musical (JAM)';
}

/**
 * Crea la instancia de Brevo API.
 */
function brevo_client(): TransactionalEmailsApi
{
    $config = Configuration::getDefaultConfiguration()
        ->setApiKey('api-key', brevo_api_key());

    return new TransactionalEmailsApi(
        new GuzzleHttp\Client(),
        $config
    );
}

/**
 * Enviar email del formulario de contacto a Visionary Code Team.
 * @return bool true si Brevo aceptó el envío
 */
function sendContactForm(string $name, string $email, string $phone, string $message, ?string $toEmail = null): bool
{
    $to = $toEmail ?: 'visionarycode.team@gmail.com';

    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
    $safePhone = htmlspecialchars($phone, ENT_QUOTES, 'UTF-8');
    $safeMsg = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));

    $emailContent = "
        <div style='font-family:Arial,sans-serif;line-height:1.5'>
          <h2>Nuevo contacto recibido</h2>
          <p><b>Nombre:</b> {$safeName}</p>
          <p><b>Email:</b> {$safeEmail}</p>
          <p><b>Teléfono:</b> {$safePhone}</p>
          <hr/>
          <p><b>Mensaje:</b></p>
          <p>{$safeMsg}</p>
        </div>
    ";

    try {
        $api = brevo_client();

        $payload = [
            'sender' => [
                'name' => brevo_sender_name(),
                'email' => brevo_sender_email()
            ],
            'to' => [[ 'email' => $to ]],
            'subject' => 'Nuevo contacto recibido',
            'htmlContent' => $emailContent
        ];

        $api->sendTransacEmail($payload);
        return true;
    } catch (ApiException $e) {
        error_log('Brevo ApiException (contact): ' . $e->getMessage());
        return false;
    } catch (Throwable $e) {
        error_log('Brevo error (contact): ' . $e->getMessage());
        return false;
    }
}

/**
 * Enviar código de recuperación al correo del usuario.
 * @return bool true si Brevo aceptó el envío
 */
function sendRecoveryEmail(string $email, string $code, int $minutesValid = 10): bool
{
    $safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
    $safeCode  = htmlspecialchars($code, ENT_QUOTES, 'UTF-8');

    $emailContent = "
        <div style='font-family:Arial,sans-serif;line-height:1.5'>
          <h2>Recuperación de contraseña - JAM</h2>
          <p>Hola,</p>
          <p>Recibimos una solicitud para recuperar tu contraseña.</p>
          <p>Tu código de verificación es:</p>
          <div style='font-size:28px;font-weight:bold;letter-spacing:4px;padding:12px 16px;background:#f3f6ff;border-radius:10px;display:inline-block'>
            {$safeCode}
          </div>
          <p style='margin-top:14px'>Este código expira en <b>{$minutesValid} minutos</b>.</p>
          <p>Si no fuiste tú, puedes ignorar este mensaje.</p>
          <hr/>
          <p style='font-size:12px;color:#6b7280'>Enviado a: {$safeEmail}</p>
        </div>
    ";

    try {
        $api = brevo_client();

        $payload = [
            'sender' => [
                'name' => brevo_sender_name(),
                'email' => brevo_sender_email()
            ],
            'to' => [[ 'email' => $email ]],
            'subject' => 'Tu código de recuperación - JAM',
            'htmlContent' => $emailContent
        ];

        $api->sendTransacEmail($payload);
        return true;
    } catch (ApiException $e) {
        error_log('Brevo ApiException (recovery): ' . $e->getMessage());
        return false;
    } catch (Throwable $e) {
        error_log('Brevo error (recovery): ' . $e->getMessage());
        return false;
    }
}
